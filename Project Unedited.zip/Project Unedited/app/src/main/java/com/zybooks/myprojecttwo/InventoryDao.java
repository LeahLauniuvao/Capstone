package com.zybooks.myprojecttwo;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface InventoryDao {

    // Insert new inventory item
    @Insert
    void insert(InventoryItem item);

    // Update existing item
    @Update
    void update(InventoryItem item);

    // Delete an item
    @Delete
    void delete(InventoryItem item);

    // Retrieve all items
    @Query("SELECT * FROM inventory_table")
    List<InventoryItem> getAllItems();
}
