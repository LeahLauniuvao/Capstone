package com.zybooks.myprojecttwo;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private List<InventoryItem> inventoryList;
    private InventoryAdapter adapter;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Initialize RecyclerView
        RecyclerView recyclerView = findViewById(R.id.inventoryRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize database and inventory list
        db = AppDatabase.getDatabase(this);
        inventoryList = new ArrayList<>();

        // Set up the adapter and link it to the RecyclerView
        adapter = new InventoryAdapter(inventoryList, this::deleteItem);
        recyclerView.setAdapter(adapter);

        // Load inventory data from the database
        loadInventoryData();

        // Initialize input fields and button
        EditText itemNameInput = findViewById(R.id.itemNameInput);
        EditText quantityInput = findViewById(R.id.quantityInput);
        Button addUpdateButton = findViewById(R.id.addUpdateButton);

        // Handle Add/Update button click
        addUpdateButton.setOnClickListener(v -> {
            String itemName = itemNameInput.getText().toString();
            String quantityString = quantityInput.getText().toString();
            if (!itemName.isEmpty() && !quantityString.isEmpty()) {
                int quantity = Integer.parseInt(quantityString);
                addItem(itemName, quantity);

                // Clear input fields after adding/updating the item
                itemNameInput.setText("");
                quantityInput.setText("");
            }
        });
    }

    private void loadInventoryData() {
        new Thread(() -> {
            List<InventoryItem> items = db.inventoryDao().getAllItems();
            runOnUiThread(() -> {
                inventoryList.clear();
                inventoryList.addAll(items);
                adapter.notifyDataSetChanged();
            });
        }).start();
    }

    private void addItem(String itemName, int quantity) {
        InventoryItem newItem = new InventoryItem(itemName, quantity);
        new Thread(() -> {
            db.inventoryDao().insert(newItem);
            runOnUiThread(() -> {
                inventoryList.add(newItem);
                adapter.notifyItemInserted(inventoryList.size() - 1);
            });
        }).start();
    }

    private void deleteItem(int position) {
        InventoryItem itemToRemove = inventoryList.get(position);
        new Thread(() -> {
            db.inventoryDao().delete(itemToRemove);
            runOnUiThread(() -> {
                inventoryList.remove(position);
                adapter.notifyItemRemoved(position);
            });
        }).start();
    }
}