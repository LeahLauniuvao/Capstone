package com.zybooks.myprojecttwo;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.Index;

@Entity(tableName = "inventory_table", indices = {@Index(value = "itemName"), @Index(value = "quantity")})
  // create indexes on columns using @Index annotation)

public class InventoryItem {
    @PrimaryKey(autoGenerate = true)
    private int id;

    private String itemName;
    private int quantity;

    // Constructor to initialize item name and quantity
    public InventoryItem(String itemName, int quantity) {
        this.itemName = itemName;
        this.quantity = quantity;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
