package com.zybooks.myprojecttwo;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.widget.Toast;
import at.favre.lib.crypto.bcrypt.BCrypt; // Import BCrypt library
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText loginUsernameInput, loginPasswordInput;
    private Button loginButton, createAccountButton;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        loginUsernameInput = findViewById(R.id.loginUsernameInput);
        loginPasswordInput = findViewById(R.id.loginPasswordInput);
        loginButton = findViewById(R.id.login_button);
        createAccountButton = findViewById(R.id.create_account_button);

        // Initialize Room database
        db = AppDatabase.getDatabase(this);

        // Handle login button click
        loginButton.setOnClickListener(v -> {
            String username = loginUsernameInput.getText().toString();
            String password = loginPasswordInput.getText().toString();
            handleLogin(username, password);
        });

        // Redirect to CreateAccountActivity when the 'Create Account' button is clicked
        createAccountButton.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, CreateAccountActivity.class);
            startActivity(intent);
        });
    }

    // Handle login logic
    private void handleLogin(String username, String password) {
        if (username.isEmpty() || password.isEmpty()) {
            // Input validation to ensure fields are not empty
            Toast.makeText(this, "Username and password cannot be empty.", Toast.LENGTH_SHORT).show();
            return;
        }

        new Thread(() -> {
            boolean success = false;
            int retries = 3;

            while (!success && retries > 0) {
                try {
                    User user = db.userDao().getUserByUsername(username);
                    runOnUiThread(() -> {
                        if (user != null) {
                            BCrypt.Result result = BCrypt.verifyer().verify(password.toCharArray(), user.getPassword());
                            if (result.verified) {
                                Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                                intent.putExtra("USERNAME", username);
                                startActivity(intent);
                                finish();
                            } else {
                                Toast.makeText(this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
                        }
                    });
                    success = true;
                } catch (Exception e) {
                    retries--;
                    Log.e("LoginActivity", "Error during login. Retries left: " + retries, e);
                    if (retries == 0) {
                        runOnUiThread(() -> Toast.makeText(this, "An error occurred. Please try again later.", Toast.LENGTH_SHORT).show());
                    } else {
                        runOnUiThread(() -> Toast.makeText(this, "Retrying login... Please wait.", Toast.LENGTH_SHORT).show());
                    }
                }
            }
        }).start();
    }
}