package com.zybooks.myprojecttwo;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;
import android.content.Context;

// Define Room database
@Database(entities = {User.class, InventoryItem.class}, version = 2)
public abstract class AppDatabase extends RoomDatabase {

    private static volatile AppDatabase INSTANCE;

    public abstract UserDao userDao();
    public abstract InventoryDao inventoryDao();

    // Define migration strategy
    private static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            // SQL command to add indices for itemName and quantity columns
            database.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_table_itemName ON inventory_table(itemName)");
            database.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_table_quantity ON inventory_table(quantity)");
        }
    };

    // Get the database instance
    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, "inventory_database")
                            .addMigrations(MIGRATION_1_2) // Apply migration
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}