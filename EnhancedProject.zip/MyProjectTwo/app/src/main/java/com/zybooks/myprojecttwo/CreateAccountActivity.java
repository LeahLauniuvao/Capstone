package com.zybooks.myprojecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import at.favre.lib.crypto.bcrypt.BCrypt;

public class CreateAccountActivity extends AppCompatActivity {

    private EditText createUsernameInput, createPasswordInput;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        // Initialize views
        createUsernameInput = findViewById(R.id.createUsernameInput);
        createPasswordInput = findViewById(R.id.createPasswordInput);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        // Initialize database
        db = AppDatabase.getDatabase(this);

        // Set up button click listener
        createAccountButton.setOnClickListener(v -> {
            String username = createUsernameInput.getText().toString().trim();
            String password = createPasswordInput.getText().toString().trim();

            if (!username.isEmpty() && !password.isEmpty()) {
                // Hash the password
                String hashedPassword = BCrypt.withDefaults().hashToString(12, password.toCharArray());

                // Insert the new user with the hashed password into the database in a background thread
                new Thread(() -> {
                    try {
                        User existingUser = db.userDao().getUserByUsername(username);
                        runOnUiThread(() -> {
                            if (existingUser == null) {
                                // Insert the new user with hashed password
                                new Thread(() -> {
                                    db.userDao().insertUser(new User(username, hashedPassword));
                                    runOnUiThread(() -> {
                                        Toast.makeText(CreateAccountActivity.this, "Account created successfully!", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(CreateAccountActivity.this, LoginActivity.class);
                                        startActivity(intent);
                                        finish();
                                    });
                                }).start();
                            } else {
                                Toast.makeText(CreateAccountActivity.this, "Username already exists!", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } catch (Exception e) {
                        runOnUiThread(() -> Toast.makeText(CreateAccountActivity.this, "An error occurred. Please try again.", Toast.LENGTH_SHORT).show());
                    }
                }).start();
            } else {
                Toast.makeText(CreateAccountActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            }
        });
    }
}