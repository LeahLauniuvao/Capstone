package com.zybooks.myprojecttwo;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

// Define a DAO interface for the User entity
@Dao
public interface UserDao {

    // Add a method to insert a new user
    @Insert
    void insertUser(User user);

    // Add a method to retrieve a user by username
    @Query("SELECT * FROM user_table WHERE username = :username LIMIT 1")
    User getUserByUsername(String username);
}