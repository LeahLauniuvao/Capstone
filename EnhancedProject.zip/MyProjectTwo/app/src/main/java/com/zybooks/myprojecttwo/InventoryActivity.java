package com.zybooks.myprojecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import android.util.Log;
import android.widget.ImageButton;
import android.widget.Toast;

public class InventoryActivity extends AppCompatActivity {

    private List<InventoryItem> inventoryList;
    private InventoryAdapter adapter;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Initialize RecyclerView
        RecyclerView recyclerView = findViewById(R.id.manageInventoryRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize database and inventory list
        db = AppDatabase.getDatabase(this);
        inventoryList = new ArrayList<>();

        // Set up the adapter and link it to the RecyclerView
        adapter = new InventoryAdapter(inventoryList, this::deleteItem);
        recyclerView.setAdapter(adapter);

        // Load inventory data from the database
        loadInventoryData();

        // Call the test data insertion method
        populateTestData();

        // Run query timing test
        testQueryPerformance();

        // Initialize input fields and button
        EditText itemNameInput = findViewById(R.id.itemNameInput);
        EditText quantityInput = findViewById(R.id.quantityInput);
        Button addUpdateButton = findViewById(R.id.addUpdateButton);

        // Handle Add/Update button click
        addUpdateButton.setOnClickListener(v -> {
            String itemName = itemNameInput.getText().toString();
            String quantityString = quantityInput.getText().toString();
            if (!itemName.isEmpty() && !quantityString.isEmpty()) {
                int quantity = Integer.parseInt(quantityString);
                addItem(itemName, quantity);

                // Clear input fields after adding/updating the item
                itemNameInput.setText("");
                quantityInput.setText("");
            }
        });

        // Initialize the Home button
        ImageButton homeButton = findViewById(R.id.homeButton); // Make sure this ID matches your XML
        homeButton.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, HomeActivity.class);
            startActivity(intent);
            finish();
        });
    }

    // Load inventory data from the database
    private void loadInventoryData() {
        new Thread(() -> {
            boolean success = false;
            int retries = 3;
            while (!success && retries > 0) {
                try {
                    List<InventoryItem> items = db.inventoryDao().getAllItems();
                    runOnUiThread(() -> {
                        inventoryList.clear();
                        inventoryList.addAll(items);
                        adapter.notifyDataSetChanged();
                    });
                    success = true;
                } catch (Exception e) {
                    Log.e("InventoryActivity", "Error loading inventory data. Retries left: " + retries, e);
                    retries--;
                    if (retries == 0) {
                        runOnUiThread(() -> Toast.makeText(this, "Failed to load inventory data after multiple attempts.", Toast.LENGTH_SHORT).show());
                    }
                }
            }
        }).start();
    }

    // Add a new item to the inventory
    private void addItem(String itemName, int quantity) {
        InventoryItem newItem = new InventoryItem(itemName, quantity);
        new Thread(() -> {
            boolean success = false;
            int retries = 3;
            while (!success && retries > 0) {
                try {
                    db.inventoryDao().insert(newItem);
                    success = true;
                    runOnUiThread(() -> {
                        inventoryList.add(newItem);
                        adapter.notifyItemInserted(inventoryList.size() - 1);
                    });
                } catch (Exception e) {
                    Log.e("InventoryActivity", "Error adding item. Retries left: " + retries, e);
                    retries--;
                    if (retries == 0) {
                        runOnUiThread(() -> Toast.makeText(this, "Failed to add item after multiple attempts.", Toast.LENGTH_SHORT).show());
                    }
                }
            }
        }).start();
    }

    // Delete an item from the inventory
    private void deleteItem(int position) {
        InventoryItem itemToRemove = inventoryList.get(position);
        new Thread(() -> {
            boolean success = false;
            int retries = 3;
            while (!success && retries > 0) {
                try {
                    db.inventoryDao().delete(itemToRemove);
                    success = true;
                    runOnUiThread(() -> {
                        inventoryList.remove(position);
                        adapter.notifyItemRemoved(position);
                    });
                } catch (Exception e) {
                    Log.e("InventoryActivity", "Error deleting item. Retries left: " + retries, e);
                    retries--;
                    if (retries == 0) {
                        runOnUiThread(() -> Toast.makeText(this, "Failed to delete item after multiple attempts.", Toast.LENGTH_SHORT).show());
                    }
                }
            }
        }).start();
    }

    // Populate test data for testing purposes
    private void populateTestData() {
        new Thread(() -> {
            try {
                if (db.inventoryDao().getAllItems().isEmpty()) {
                    for (int i = 1; i <= 1000; i++) {
                        InventoryItem item = new InventoryItem("Item " + i, i);
                        db.inventoryDao().insert(item);
                    }
                    Log.d("DatabaseTest", "Test data inserted successfully.");
                } else {
                    Log.d("DatabaseTest", "Test data already exists, no insertion needed.");
                }
            } catch (Exception e) {
                Log.e("InventoryActivity", "Error populating test data", e);
            }
        }).start();
    }

    // Run a query to test the performance of the database
    private void testQueryPerformance() {
        new Thread(() -> {
            boolean success = false;
            int retries = 3;
            while (!success && retries > 0) {
                try {
                    long startTime = System.currentTimeMillis();

                    // Run the database query
                    List<InventoryItem> items = db.inventoryDao().getAllItems();

                    long endTime = System.currentTimeMillis();

                    // Log the time taken to execute the query
                    Log.d("DatabaseTest", "Query execution time: " + (endTime - startTime) + " ms");
                    success = true;
                } catch (Exception e) {
                    Log.e("InventoryActivity", "Error running query performance test. Retries left: " + retries, e);
                    retries--;
                    if (retries == 0) {
                        runOnUiThread(() -> Toast.makeText(this, "Failed to run query performance test after multiple attempts.", Toast.LENGTH_SHORT).show());
                    }
                }
            }
        }).start();
    }
}