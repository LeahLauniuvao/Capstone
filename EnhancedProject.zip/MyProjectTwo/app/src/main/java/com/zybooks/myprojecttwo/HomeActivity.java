package com.zybooks.myprojecttwo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private List<InventoryItem> inventoryList;
    private InventoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Retrieve the username from login activity
        String username = getIntent().getStringExtra("USERNAME");

        // Set the welcome header
        TextView welcomeHeader = findViewById(R.id.welcomeHeader);
        if (username != null) {
            welcomeHeader.setText("Welcome, " + username);
        } else {
            welcomeHeader.setText("Welcome");
        }

        // Button for opening inventory management
        Button openInventoryButton = findViewById(R.id.openInventoryButton);
        openInventoryButton.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, InventoryActivity.class);
            startActivity(intent);
        });

        // Initialize RecyclerView
        RecyclerView recyclerView = findViewById(R.id.homeInventoryRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize inventory list and adapter
        inventoryList = new ArrayList<>();
        adapter = new InventoryAdapter(inventoryList, this::deleteItem);
        recyclerView.setAdapter(adapter);

        // Initialize input fields and add button
        EditText homeItemNameInput = findViewById(R.id.homeItemNameInput);
        EditText quantityInput = findViewById(R.id.quantityInput);
        Button addDataButton = findViewById(R.id.addDataButton);

        addDataButton.setOnClickListener(v -> {
            String itemName = homeItemNameInput.getText().toString();
            String quantityString = quantityInput.getText().toString();
            if (!itemName.isEmpty() && !quantityString.isEmpty()) {
                int quantity = Integer.parseInt(quantityString);
                addItem(itemName, quantity);

                // Clear input fields
                homeItemNameInput.setText("");
                quantityInput.setText("");
            }
        });

        // Load inventory data from the database
        loadInventoryData();

        // SMS Notification Checkbox logic
        CheckBox enableSMSCheckbox = findViewById(R.id.enableSMSCheckbox);
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        boolean isSMSEnabled = sharedPreferences.getBoolean("SMS_ENABLED", false);
        enableSMSCheckbox.setChecked(isSMSEnabled);

        enableSMSCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("SMS_ENABLED", isChecked);
            editor.apply();
        });

        // Send SMS Button logic
        Button sendSMSButton = findViewById(R.id.sendSMSButton);
        sendSMSButton.setOnClickListener(v -> {
            String message = "Your SMS content here";
            String phoneNumber = "2532668411";  // Test number

            Intent smsIntent = new Intent(Intent.ACTION_SENDTO);
            smsIntent.setData(Uri.parse("sms to:" + phoneNumber));
            smsIntent.putExtra("sms_body", message);

            if (smsIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(smsIntent);
            } else {
                Toast.makeText(HomeActivity.this, "No SMS app available", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadInventoryData() {
        new Thread(() -> {
            List<InventoryItem> items = AppDatabase.getDatabase(this).inventoryDao().getAllItems();
            runOnUiThread(() -> {
                inventoryList.clear();
                inventoryList.addAll(items);
                adapter.notifyDataSetChanged();
            });
        }).start();
    }

    private void addItem(String itemName, int quantity) {
        InventoryItem newItem = new InventoryItem(itemName, quantity);
        new Thread(() -> {
            AppDatabase.getDatabase(this).inventoryDao().insert(newItem);
            runOnUiThread(() -> {
                inventoryList.add(newItem);
                adapter.notifyItemInserted(inventoryList.size() - 1);
            });
        }).start();
    }

    private void deleteItem(int position) {
        InventoryItem itemToRemove = inventoryList.get(position);
        new Thread(() -> {
            AppDatabase.getDatabase(this).inventoryDao().delete(itemToRemove);
            runOnUiThread(() -> {
                inventoryList.remove(position);
                adapter.notifyItemRemoved(position);
            });
        }).start();
    }
}